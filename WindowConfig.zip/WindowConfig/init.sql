-- Initialize WindoorConfig Database
-- This file will be executed when PostgreSQL container starts

-- Create database if not exists
-- (This is handled by POSTGRES_DB environment variable)

-- Grant privileges to user
GRANT ALL PRIVILEGES ON DATABASE windoor_db TO windoor_user;

-- Set timezone
SET timezone = 'Europe/Warsaw';