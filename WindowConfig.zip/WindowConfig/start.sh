#!/bin/bash

# WindoorConfig - Skrypt uruchamiający aplikację w Docker
# Autor: System WindoorConfig
# Data: $(date +%Y-%m-%d)

echo "🏗️  WindoorConfig - System konfiguracji ofert stolarki okiennej"
echo "========================================================"

# Sprawdź czy Docker jest zainstalowany
if ! command -v docker &> /dev/null; then
    echo "❌ Docker nie jest zainstalowany!"
    echo "Zainstaluj Docker z: https://docker.com/products/docker-desktop"
    exit 1
fi

# Sprawdź czy Docker Compose jest zainstalowany
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose nie jest zainstalowany!"
    echo "Zainstaluj Docker Compose lub użyj Docker Desktop"
    exit 1
fi

echo "✅ Docker i Docker Compose są dostępne"

# Sprawdź czy Docker daemon działa
if ! docker info &> /dev/null; then
    echo "❌ Docker daemon nie działa!"
    echo "Uruchom Docker Desktop lub 'sudo systemctl start docker'"
    exit 1
fi

echo "✅ Docker daemon działa"

# Sprawdź czy port 5000 jest wolny
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "⚠️  Port 5000 jest zajęty!"
    echo "Zatrzymaj aplikację na porcie 5000 lub zmień port w docker-compose.yml"
    read -p "Czy chcesz kontynuować mimo to? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "🚀 Uruchamianie WindoorConfig..."

# Sprawdź czy istnieją kontenery z poprzedniego uruchomienia
if docker-compose ps -q | grep -q .; then
    echo "📋 Znaleziono istniejące kontenery"
    read -p "Czy chcesz zatrzymać i usunąć stare kontenery? (Y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Nn]$ ]]; then
        echo "🔄 Pozostawiam istniejące kontenery"
    else
        echo "🗑️  Zatrzymuję i usuwam stare kontenery..."
        docker-compose down
    fi
fi

# Buduj i uruchom aplikację
echo "🏗️  Budowanie i uruchamianie aplikacji..."
docker-compose up -d --build

# Sprawdź status
echo "📊 Sprawdzanie statusu kontenerów..."
sleep 5

# Wyświetl status kontenerów
docker-compose ps

# Sprawdź czy aplikacja odpowiada
echo "🌐 Testowanie połączenia z aplikacją..."
sleep 10

if curl -f http://localhost:5000/api/health &> /dev/null; then
    echo "✅ Aplikacja działa poprawnie!"
    echo ""
    echo "🎉 WindoorConfig jest gotowy do użycia!"
    echo "🌐 Otwórz przeglądarkę i przejdź do: http://localhost:5000"
    echo ""
    echo "👤 Domyślne konto administratora:"
    echo "   Email: admin@windoor.com"
    echo "   Hasło: admin123"
    echo ""
    echo "⚠️  Pamiętaj o zmianie hasła administratora!"
    echo ""
    echo "📊 Aby sprawdzić logi: docker-compose logs -f"
    echo "🛑 Aby zatrzymać: docker-compose down"
else
    echo "❌ Aplikacja nie odpowiada!"
    echo "📋 Sprawdź logi: docker-compose logs"
    echo "🔄 Spróbuj ponownie: docker-compose restart"
fi

echo ""
echo "📖 Pełną dokumentację znajdziesz w pliku README-Docker.md"