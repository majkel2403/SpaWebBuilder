import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from app.config import settings

# Create database engine
# Use PostgreSQL for Docker deployment, SQLite for local development
DATABASE_URL = settings.DATABASE_URL or settings.SQLITE_URL

# Create SQLAlchemy engine
if DATABASE_URL.startswith("postgresql"):
    # PostgreSQL configuration for Docker
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,  # Test connections before using them
        pool_recycle=300,    # Recycle connections every 5 minutes
        pool_size=10,        # Number of connections to keep open
        max_overflow=20      # Number of connections to allow beyond pool_size
    )
else:
    # SQLite configuration for local development
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,  # Test connections before using them
        connect_args={"check_same_thread": False}  # Tylko dla SQLite
    )

# Create SessionLocal class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create Base class for database models
Base = declarative_base()
