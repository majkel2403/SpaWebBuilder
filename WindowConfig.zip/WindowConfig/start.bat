@echo off
chcp 65001 >nul
title WindoorConfig - System konfiguracji ofert

echo 🏗️  WindoorConfig - System konfiguracji ofert stolarki okiennej
echo ========================================================

REM Sprawdź czy Docker jest zainstalowany
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Docker nie jest zainstalowany!
    echo Zainstaluj Docker Desktop z: https://docker.com/products/docker-desktop
    pause
    exit /b 1
)

REM Sprawdź czy Docker Compose jest dostępny
docker-compose --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Docker Compose nie jest dostępny!
    echo Użyj Docker Desktop lub zainstaluj Docker Compose
    pause
    exit /b 1
)

echo ✅ Docker i Docker Compose są dostępne

REM Sprawdź czy Docker daemon działa
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Docker Desktop nie działa!
    echo Uruchom Docker Desktop i spróbuj ponownie
    pause
    exit /b 1
)

echo ✅ Docker Desktop działa

echo 🚀 Uruchamianie WindoorConfig...

REM Zatrzymaj stare kontenery jeśli istnieją
docker-compose down >nul 2>&1

REM Buduj i uruchom aplikację
echo 🏗️  Budowanie i uruchamianie aplikacji...
docker-compose up -d --build

if %errorlevel% neq 0 (
    echo ❌ Błąd podczas uruchamiania aplikacji!
    echo Sprawdź logi: docker-compose logs
    pause
    exit /b 1
)

echo 📊 Sprawdzanie statusu kontenerów...
timeout /t 10 /nobreak >nul

REM Wyświetl status kontenerów
docker-compose ps

echo 🌐 Testowanie połączenia z aplikacją...
timeout /t 10 /nobreak >nul

REM Sprawdź czy aplikacja odpowiada (Windows nie ma curl, więc użyjemy powershell)
powershell -Command "try { Invoke-WebRequest -Uri 'http://localhost:5000/api/health' -UseBasicParsing | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1

if %errorlevel% equ 0 (
    echo.
    echo ✅ Aplikacja działa poprawnie!
    echo.
    echo 🎉 WindoorConfig jest gotowy do użycia!
    echo 🌐 Otwórz przeglądarkę i przejdź do: http://localhost:5000
    echo.
    echo 👤 Domyślne konto administratora:
    echo    Email: admin@windoor.com
    echo    Hasło: admin123
    echo.
    echo ⚠️  Pamiętaj o zmianie hasła administratora!
    echo.
    echo 📊 Aby sprawdzić logi: docker-compose logs -f
    echo 🛑 Aby zatrzymać: docker-compose down
    echo.
    echo Czy chcesz otworzyć aplikację w przeglądarce? (T/N)
    set /p choice=
    if /i "%choice%"=="T" start http://localhost:5000
) else (
    echo ❌ Aplikacja nie odpowiada!
    echo 📋 Sprawdź logi: docker-compose logs
    echo 🔄 Spróbuj ponownie: docker-compose restart
)

echo.
echo 📖 Pełną dokumentację znajdziesz w pliku README-Docker.md
echo.
pause