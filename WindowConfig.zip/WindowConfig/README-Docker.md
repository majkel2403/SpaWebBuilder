# WindoorConfig - Uruchomienie w Docker

## 🚀 Szybki start z Docker

Twoja aplikacja WindoorConfig jest teraz gotowa do uruchomienia w Dockerze na każdym urządzeniu!

### Wymagania
- Docker (wersja 20.0+)
- Docker Compose (wersja 2.0+)

### Instalacja Docker

#### Windows:
1. Pobierz Docker Desktop z https://docker.com/products/docker-desktop
2. Zainstaluj i uruchom Docker Desktop

#### macOS:
1. Pobierz Docker Desktop z https://docker.com/products/docker-desktop
2. Zainstaluj i uruchom Docker Desktop

#### Linux (Ubuntu/Debian):
```bash
sudo apt update
sudo apt install docker.io docker-compose
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER
```

## 📦 Uruchomienie aplikacji

### Metoda 1: Docker Compose (ZALECANA)

1. **Pobierz kod aplikacji:**
```bash
git clone <twoje-repo>
cd windoor-config
```

2. **Uruchom aplikację jednym poleceniem:**
```bash
docker-compose up -d
```

3. **Sprawdź status:**
```bash
docker-compose ps
```

4. **Otwórz aplikację w przeglądarce:**
```
http://localhost:5000
```

### Metoda 2: Tylko Docker (bez bazy danych)

1. **Zbuduj obraz:**
```bash
docker build -t windoor-config .
```

2. **Uruchom kontener:**
```bash
docker run -p 5000:5000 windoor-config
```

## 🔧 Zarządzanie aplikacją

### Zatrzymanie aplikacji:
```bash
docker-compose down
```

### Zatrzymanie z usunięciem danych:
```bash
docker-compose down -v
```

### Przebudowanie aplikacji:
```bash
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

### Sprawdzenie logów:
```bash
# Wszystkie usługi
docker-compose logs

# Tylko aplikacja
docker-compose logs windoor-app

# Tylko baza danych
docker-compose logs postgres

# Na żywo
docker-compose logs -f
```

## 📊 Dostęp do bazy danych

Gdy aplikacja działa, baza PostgreSQL jest dostępna na:
- **Host:** localhost
- **Port:** 5432
- **Baza:** windoor_db
- **Użytkownik:** windoor_user
- **Hasło:** windoor_password

### Połączenie przez pgAdmin lub inny klient:
```
Host: localhost
Port: 5432
Database: windoor_db
Username: windoor_user
Password: windoor_password
```

## 🔐 Domyślne konto administratora

Po pierwszym uruchomieniu zostanie utworzone konto administratora:
- **Email:** admin@windoor.com
- **Hasło:** admin123

**⚠️ WAŻNE:** Zmień hasło administratora po pierwszym logowaniu!

## 📁 Struktura katalogów Docker

```
windoor-config/
├── Dockerfile              # Konfiguracja obrazu Docker
├── docker-compose.yml      # Orkiestracja kontenerów
├── init.sql                # Inicjalizacja bazy danych
├── .dockerignore           # Pliki ignorowane przez Docker
├── backend/                # Kod aplikacji backend
├── frontend/               # Kod aplikacji frontend
└── Rozszerzona_tabela_opcji.csv  # Dane opcji produktów
```

## 🛠️ Rozwiązywanie problemów

### Problem: Port 5000 jest zajęty
```bash
# Znajdź proces na porcie 5000
sudo lsof -i :5000

# Zatrzymaj konfliktujący proces lub zmień port w docker-compose.yml
```

### Problem: Baza danych nie startuje
```bash
# Sprawdź logi PostgreSQL
docker-compose logs postgres

# Usuń stare dane (UWAGA: usuwa wszystkie dane!)
docker-compose down -v
docker-compose up -d
```

### Problem: Aplikacja nie łączy się z bazą
```bash
# Sprawdź status wszystkich kontenerów
docker-compose ps

# Zrestartuj aplikację
docker-compose restart windoor-app
```

## 🌐 Wdrożenie na serwer

### Na VPS/serwerze dedykowanym:

1. **Skopiuj pliki na serwer:**
```bash
scp -r windoor-config/ user@your-server:/home/user/
```

2. **Zaloguj się na serwer i uruchom:**
```bash
ssh user@your-server
cd windoor-config
docker-compose up -d
```

3. **Konfiguruj firewall (jeśli potrzeba):**
```bash
sudo ufw allow 5000
```

### Zmiana portu dla produkcji:
W pliku `docker-compose.yml` zmień:
```yaml
ports:
  - "80:5000"  # Aplikacja będzie dostępna na porcie 80
```

## 📈 Backup i restore danych

### Backup bazy danych:
```bash
docker-compose exec postgres pg_dump -U windoor_user windoor_db > backup.sql
```

### Restore bazy danych:
```bash
docker-compose exec -T postgres psql -U windoor_user windoor_db < backup.sql
```

## ⚡ Optymalizacja wydajności

### Dla produkcji dodaj do docker-compose.yml:
```yaml
windoor-app:
  # ... inne ustawienia
  deploy:
    resources:
      limits:
        memory: 1G
        cpus: '0.5'
  restart: always
```

## 🔄 Aktualizacja aplikacji

1. **Pobierz nową wersję:**
```bash
git pull origin main
```

2. **Przebuduj i uruchom:**
```bash
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

---

## 📞 Wsparcie

W przypadku problemów sprawdź logi aplikacji:
```bash
docker-compose logs -f windoor-app
```

Twoja aplikacja WindoorConfig jest teraz gotowa do działania na każdym urządzeniu z Docker! 🎉